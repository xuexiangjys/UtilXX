package com.ryg.dynamicload.sample.mainplugin;

public interface ResourceConstants {

    interface LayoutResource {
    }
}
