package com.ryg.dynamicload.sample.docommon;

import android.content.Context;

public interface HostInterface {

    public void hostMethod(Context context);
}
