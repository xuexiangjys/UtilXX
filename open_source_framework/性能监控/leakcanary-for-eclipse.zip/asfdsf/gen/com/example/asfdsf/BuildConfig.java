/** Automatically generated file. DO NOT MODIFY */
package com.example.asfdsf;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}