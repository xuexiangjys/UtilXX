package com.example.asfdsf;

import android.app.Activity;
import android.os.Bundle;

public class OtherActivity extends Activity{
	public static Object[] a = new Object[1000000];
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_other);
		for (int i = 0; i < a.length; i++) {
			a[i] = new Object();
		}
		ActivityManager.getInstence(this).registActivity(this);
	}
}
