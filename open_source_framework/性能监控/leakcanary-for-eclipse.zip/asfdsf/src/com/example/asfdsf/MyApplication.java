package com.example.asfdsf;

import com.squareup.leakcanary.LeakCanary;

import android.app.Application;

public class MyApplication extends Application{
	
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		LeakCanary.install(this);
		super.onCreate();
	}
}
