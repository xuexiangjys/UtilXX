package com.example.asfdsf;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;

public class ActivityManager {
	public static ActivityManager instance;
	private List<Activity> mActivities = new ArrayList<Activity>();

	public static ActivityManager getInstence(Context context) {
		if (instance == null) {
			instance = new ActivityManager();
		}
		return instance;
	}

	public void registActivity(Activity activity) {
		mActivities.add(activity);
	}

	public void unRigistActivity(Activity activity) {
		mActivities.remove(activity);
	}
}
