/** Automatically generated file. DO NOT MODIFY */
package com.squareup.leakcanary.android.noop;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}